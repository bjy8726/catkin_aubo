## if you want to use aubo model in gazebo,you need install package as follows: ##

**1.sudo apt-get install ros-kinetic-desktop-full**  

**2.sudo apt-get install ros-kinetic-transmission-interface**  

**3.sudo apt-get install ros-kinetic-gazebo-ros-control**  

**4.sudo apt-get install ros-kinetic-joint-state-controller**  

**5.sudo apt-get install ros-kinetic-effort-controllers**  

**6.sudo apt-get install ros-kinetic-position-controllers**  

**7.sudo apt-get install ros-kinetic-control-manager**



