^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package aubo_kinematics
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.0 (2016-11-15)
------------------

0.2.2 (2016-10-27)
------------------

0.2.1 (2016-10-11)
------------------

0.2.0 (2016-10-11)
------------------

0.1.2 (2016-09-30)
------------------

0.1.1 (2016-09-20)
------------------
* update CHANGELOG.rst
* Contributors: robot

0.1.0 (2016-09-19)
------------------
* add CHANGELOG.rst
* update version 0.0.1
* update README
* Aubo robotics ROS version 1.0
* Contributors: robot
