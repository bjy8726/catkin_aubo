echo "start update"

cp libmoveit_trajectory_processing.so* /opt/ros/kinetic/lib/

echo "update end"
