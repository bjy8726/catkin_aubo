AUBO Robot Description

A description package for the aubo_i3/aubo_i5/aubo_i7 robot arms from AUBO Robots. The 3D model files should be simplified to improve the computation efficiency in robot planning and collision detection.

We will add the aubo_i10 package soon.




